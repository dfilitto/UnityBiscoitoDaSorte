using UnityEngine;
using UnityEngine.UIElements;

public class UIController : MonoBehaviour
{
    private UIDocument uiDocument;
    private Button botaoBiscoito;
    private Label textoFrase;

    private string[] frases = {
        "A sorte favorece os audazes.",
        "Sua criatividade o levar� a grandes lugares.",
        "Um novo desafio trar� grandes recompensas.",
        "A paci�ncia � a chave para o sucesso.",
        "Amanh� ser� um dia de grandes conquistas!",
        "Acredite em si mesmo e o resto vir� naturalmente.",
        "A vida � uma jornada, aproveite cada passo."
    };

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        uiDocument = GetComponent<UIDocument>();
        botaoBiscoito = uiDocument.rootVisualElement.Q<Button>("botao-biscoito");
        textoFrase = uiDocument.rootVisualElement.Q<Label>("texto-frase");
        botaoBiscoito.clicked += QuebrarBiscoito;
    }

    private void QuebrarBiscoito()
    {
        int indiceAleatorio = Random.Range(0, frases.Length);
        textoFrase.text = frases[indiceAleatorio];
        botaoBiscoito.text = "Quebrar outro biscoito";
    }
}
